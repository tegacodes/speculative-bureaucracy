document.body.innerHTML = document.body.innerHTML.replace(new RegExp("climate change", "g"), "capitalism");
document.body.innerHTML = document.body.innerHTML.replace(new RegExp("Climate change", "g"), "Capitalism");

//NOTES AND LINKS ON THIS:
//for case insensitive matching replace g with gi.
//Regular expressions: http://www.w3schools.com/jsref/jsref_regexp_g.asp
//Document.body.innerHTML: http://www.w3schools.com/jsref/prop_doc_body.asp
//Document object: http://www.w3schools.com/js/js_htmldom_document.asp
//.replace method: http://www.w3schools.com/jsref/jsref_replace.asp

//Argrhhh.. Shiffman on regular expressions!!
//http://shiffman.github.io/A2Z-F15/week3/notes.html